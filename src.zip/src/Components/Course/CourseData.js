export const Course = [
    {
        id: 1,
        img: "https://i.ytimg.com/vi/lC5f2xqWBag/maxresdefault.jpg",
        item: "Power Yoga",
        Price: 1499
    },
    {
        id: 2,
        img: "https://tse4.mm.bing.net/th?id=OIP.64Y6CSFdlFfa3o4NUVNGGgHaFZ&pid=Api&P=0",
        item: "Strength Training",
        Price: 1999
    },
    {
        id: 3,
        img: "https://www.rxbodybuilders.com/wp-content/uploads/functional-strength-training.jpg",
        item: "Weight Lifting",
        Price: 1699
    },
    {
        id: 4,
        img: "https://img.aws.livestrongcdn.com/ls-1200x630/s3-us-west-1.amazonaws.com/contentlab.studiod/getty/442b18e925d4404295772c6775e995d5",
        item: "Cardio",
        Price: 1299
    },
    {
        id: 5,
        img: "https://www.g4physio.co.uk/wp-content/uploads/2020/01/dance-fitness-04.jpg",
        item: "Dance Fitness",
        Price: 2499
    },
    {
        id: 6,
        img: "http://www.gymchalo.com/wp-content/uploads/2016/01/swimming.jpg",
        item: "Swimming",
        Price: 2299
    },

]