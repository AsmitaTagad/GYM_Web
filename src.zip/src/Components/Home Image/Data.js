export const Data =[
   "https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?cs=srgb&dl=pexels-leon-ardho-1552242.jpg&fm=jpg"
    ,
       "https://i.ytimg.com/vi/gey73xiS8F4/maxresdefault.jpg",
    "https://dungcutheduc.vn/images/contents/fitness.jpg"
    ,
"https://img.freepik.com/free-photo/woman-holding-barbell-shoulders-gym_651396-1603.jpg"
    ,
   "https://t4.ftcdn.net/jpg/01/74/21/25/360_F_174212531_cerVf4uP6vinBWieBB46p2P5xVhnsNSK.jpg"
    ,
   "https://media.istockphoto.com/id/1183038884/photo/view-of-a-row-of-treadmills-in-a-gym-with-people.jpg?s=170667a&w=0&k=20&c=4rRa3N8jumd-iM2CXMS3MXtcpv0C7V_J_C4MjSOaMjo="
    ,
   "https://media.istockphoto.com/id/615883260/photo/difficult-doesnt-mean-impossible.jpg?s=612x612&w=0&k=20&c=cAEJvjTFRuF9H9gRov1Aj4X4I6xV6DSvMwWsf-2IW-0="
    ,
   "https://img.freepik.com/premium-photo/muscular-fitness-man-preparing-deadlift-barbell-his-head-modern-fitness-center-functional-training_136403-900.jpg"
    ,
    "https://media.istockphoto.com/id/1127952489/photo/flying-rope-in-gym-training.jpg?s=612x612&w=0&k=20&c=RfZKv8MAnqJFj7LwKiyP1YpjRRwVUgokBy0ngK22Nc4="
    ,
   "https://www.fitnessbeforeandafter.com/wp-content/uploads/2020/07/yoga-cardio-exercise-6-scaled.jpg"
    

]